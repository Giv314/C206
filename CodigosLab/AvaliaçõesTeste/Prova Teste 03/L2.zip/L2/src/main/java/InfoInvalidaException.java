public class InfoInvalidaException extends RuntimeException{
    InfoInvalidaException(){

    }
}
