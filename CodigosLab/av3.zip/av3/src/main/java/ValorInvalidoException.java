public class ValorInvalidoException extends RuntimeException{
    ValorInvalidoException(String msg){
        super(msg);
    }
}
